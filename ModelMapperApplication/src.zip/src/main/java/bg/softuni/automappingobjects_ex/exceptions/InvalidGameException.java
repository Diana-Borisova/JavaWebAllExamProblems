package bg.softuni.automappingobjects_ex.exceptions;

public class InvalidGameException extends RuntimeException {
    public InvalidGameException() {
        super("Invalid Game!");
    }

}
