package bg.softuni.automappingobjects_ex.models.services;

import bg.softuni.automappingobjects_ex.exceptions.GameAlreadyExistsException;
import bg.softuni.automappingobjects_ex.models.dtos.AddGameDTO;
import bg.softuni.automappingobjects_ex.models.dtos.UserLoginDTO;
import bg.softuni.automappingobjects_ex.models.dtos.UserRegistrationDTO;
import bg.softuni.automappingobjects_ex.models.entity.Game;
import bg.softuni.automappingobjects_ex.models.entity.User;

import java.util.Set;

public interface UserService {
    void register(UserRegistrationDTO registerDTO);

    User login(UserLoginDTO loginDTO);

    User logout();

    Game addGame(AddGameDTO addGameDTO) throws GameAlreadyExistsException;

    Game editGame(long id, String[] args);

    Game deleteGame(long id);

    String showOwnedGames();

    Game addItem(String title);

    Game removeItem(String title);

    Set<Game> buyItems();
}