package bg.softuni.automappingobjects_ex.exceptions;

public class AnotherAccountInUseException extends RuntimeException {
    public AnotherAccountInUseException() {
        super("Another user is logged in!");
    }
}