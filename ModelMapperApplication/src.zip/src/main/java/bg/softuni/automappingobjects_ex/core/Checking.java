package bg.softuni.automappingobjects_ex.core;


import bg.softuni.automappingobjects_ex.exceptions.AccountNotLoggedInException;
import bg.softuni.automappingobjects_ex.exceptions.AnotherAccountInUseException;
import bg.softuni.automappingobjects_ex.exceptions.InsufficientPermissionException;
import bg.softuni.automappingobjects_ex.models.entity.User;

public class Checking {

    public static void checkIfAnotherUserIsLogged(User currentUser) {
        if (currentUser != null) {
            throw new AnotherAccountInUseException();
        }
    }

    public static void checkIfLoggedAndAdmin(User currentUser) {
        if (currentUser == null) {
            throw new AccountNotLoggedInException("Cannot operate while logged out!");
        }

        if (!currentUser.isAdmin()) {
            throw new InsufficientPermissionException();
        }
    }

    public static void isLogged(User currentUser) {
        if (currentUser == null) {
            throw new AccountNotLoggedInException("Cannot operate while logged out!");
        }
    }
}