package bg.softuni.automappingobjects_ex.exceptions;

public class GameAlreadyExistsException extends RuntimeException {
    public GameAlreadyExistsException() {
        super("Game already added!");
    }

    public GameAlreadyExistsException(String message) {
        super(message);
    }
}