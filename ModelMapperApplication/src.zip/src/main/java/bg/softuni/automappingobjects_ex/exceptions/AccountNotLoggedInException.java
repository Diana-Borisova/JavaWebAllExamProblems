package bg.softuni.automappingobjects_ex.exceptions;

public class AccountNotLoggedInException extends RuntimeException {
    public AccountNotLoggedInException() {
        super("Cannot log out. No user was logged in.");
    }

    public AccountNotLoggedInException(String message) {
        super(message);
    }
}