package bg.softuni.automappingobjects_ex.models.dtos;

import bg.softuni.automappingobjects_ex.core.Validations;
import bg.softuni.automappingobjects_ex.exceptions.WrongCredentialsException;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserLoginDTO {
    private String email;
    private String password;

    public UserLoginDTO(String[] commandParts) {
        this.email = commandParts[1];
        this.password = commandParts[2];
        validate();
    }

    private void validate(){
        if (!Validations.isValid(this.email, this.password)){
            throw new WrongCredentialsException("Incorrect username / password");
        }
    }
}