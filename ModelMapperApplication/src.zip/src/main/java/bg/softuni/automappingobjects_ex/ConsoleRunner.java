package bg.softuni.automappingobjects_ex;


import bg.softuni.automappingobjects_ex.exceptions.*;
import bg.softuni.automappingobjects_ex.messages.GameOutputMessages;
import bg.softuni.automappingobjects_ex.models.services.ExecutorService;
import lombok.AllArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Scanner;

@AllArgsConstructor
@Component
public class ConsoleRunner implements CommandLineRunner {

    private ExecutorService executorService;
    private Scanner scanner;

    @Override
    public void run(String... args) {
        String input = scanner.nextLine();

        try{
            while (!input.equals("Close")){
                System.out.println(this.executorService.execute(input));
                input = scanner.nextLine();
            }
        } catch (AccountNotLoggedInException | AnotherAccountInUseException | NoSuchAccountException | UserAlreadyExistsException | WrongCredentialsException |
                 GameAlreadyExistsException | InsufficientPermissionException | InvalidGameException | GameNotExistsException | NoSuchOperationExists e) {
            System.out.println(e.getMessage());
        }
    }
}