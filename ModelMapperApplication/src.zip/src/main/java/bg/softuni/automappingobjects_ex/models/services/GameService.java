package bg.softuni.automappingobjects_ex.models.services;

import bg.softuni.automappingobjects_ex.models.entity.Game;
public interface GameService {
    void addGame(Game game);

    Game editGame(long id, String[] commandParts);

    Game deleteGame(long idToDelete);

    String showAllGames();

    String showDetailGame(String title);

    Game findByTitle(String title);
}