package bg.softuni.automappingobjects_ex.messages;

public class UserOutputMessages {
    public static final String REGISTERED_USER_MSG = "%s was registered";
    public static final String LOGIN_USER_MSG = "Successfully logged in %s";
    public static final String LOGOUT_USER_MSG = "User %s successfully logged out";
}
