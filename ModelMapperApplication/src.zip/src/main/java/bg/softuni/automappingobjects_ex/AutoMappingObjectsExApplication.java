package bg.softuni.automappingobjects_ex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutoMappingObjectsExApplication {

    public static void main(String[] args) {
        SpringApplication.run(AutoMappingObjectsExApplication.class, args);
    }

}
