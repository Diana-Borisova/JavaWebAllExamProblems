package bg.softuni.automappingobjects_ex.models.repositories;

import bg.softuni.automappingobjects_ex.models.dtos.DetailsGameDTO;
import bg.softuni.automappingobjects_ex.models.entity.Game;


import bg.softuni.automappingobjects_ex.models.entity.TitlePriceGame;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.Set;

@Repository
public interface GameRepository extends JpaRepository<Game, Long> {
    Optional<Game> findByTitle(String title);
    Set<TitlePriceGame> findAllBy();
    Set<DetailsGameDTO> findAllByTitle(String title);
}