package bg.softuni.automappingobjects_ex.exceptions;
public class NoSuchAccountException extends RuntimeException{

    public NoSuchAccountException(String message) {
        super(message);
    }
}