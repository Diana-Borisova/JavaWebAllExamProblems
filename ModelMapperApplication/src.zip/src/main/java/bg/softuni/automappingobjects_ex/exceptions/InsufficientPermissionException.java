package bg.softuni.automappingobjects_ex.exceptions;

public class InsufficientPermissionException extends RuntimeException {
    public InsufficientPermissionException() {
        super("You don't have permission to perform this action!");
    }

}