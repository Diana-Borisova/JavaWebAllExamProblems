package bg.softuni.automappingobjects_ex.exceptions;

public class GameNotExistsException extends RuntimeException {
    public GameNotExistsException() {
        super("Game doesn't exist!");
    }

    public GameNotExistsException(String message) {
        super(message);
    }
}