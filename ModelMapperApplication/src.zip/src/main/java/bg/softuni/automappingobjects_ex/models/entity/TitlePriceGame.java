package bg.softuni.automappingobjects_ex.models.entity;
import java.math.BigDecimal;

public interface TitlePriceGame {
    String getTitle();
    BigDecimal getPrice();
}