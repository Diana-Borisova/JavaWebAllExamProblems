package bg.softuni.automappingobjects_ex.exceptions;

public class UserAlreadyExistsException extends RuntimeException {
    public UserAlreadyExistsException() {
        super("User with the same email already exists!");
    }

}