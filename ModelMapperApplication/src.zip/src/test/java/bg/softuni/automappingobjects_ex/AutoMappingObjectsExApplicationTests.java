package bg.softuni.automappingobjects_ex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoMappingObjectsExApplicationTests {

    @Test
    void contextLoads() {
    }

}
