package com.softuni.andrey.s.entity;

import lombok.Getter;

@Getter
public enum CategoryNameEnum {
    Shirt, Denim, Shorts, Jacket;
}
