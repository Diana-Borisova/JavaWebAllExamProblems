package com.softuni.andrey.s.entity;

import lombok.Getter;

@Getter
public enum GenderEnum {

    MALE, FEMALE;
}
