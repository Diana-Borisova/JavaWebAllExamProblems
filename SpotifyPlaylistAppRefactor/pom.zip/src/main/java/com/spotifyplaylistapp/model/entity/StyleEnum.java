package com.spotifyplaylistapp.model.entity;

import lombok.Getter;

@Getter
public enum StyleEnum {

    POP, ROCK, JAZZ;
}
